fn swapnumbers(x: &mut i32, y: &mut i32) {
    let temp = *x;  // Initialize temp with the value of *x
    *x = *y;
    *y = temp;
}

fn main() {
    let mut a = 15;
    let mut b = 25;

    swapnumbers(&mut a, &mut b);

    println!("a = {}, b = {}", a, b);  // Print the swapped values
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_swapnumbers() {
        let mut a = 15;
        let mut b = 25;

        swapnumbers(&mut a, &mut b);

        assert_eq!(a, 25);
        assert_eq!(b, 15);
    }
}
